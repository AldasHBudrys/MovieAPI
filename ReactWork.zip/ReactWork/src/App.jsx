import React from 'react';
import AuthForm from './components/AuthForm';

function App() {
  return <AuthForm />;
}

export default App;
