import React from 'react';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <div style={styles.container}>
      <h1>I did not have enough time to finish all the front end, please use postman to properly login with the account you made, and check out the post and get functionality! <br/> Neturėjau laiko užbaigti front-end dalies, prašau prisijungti su jūsų sukurtu vartotoju per postman ir išbandyti post ir get funkcionalumą</h1>
      <button onClick={logout} style={styles.btn}>
        Logout
      </button>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    textAlign: 'center',
  },
  btn: {
    padding: '0.5rem 1rem',
    background: '#d9534f',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default Dashboard;
