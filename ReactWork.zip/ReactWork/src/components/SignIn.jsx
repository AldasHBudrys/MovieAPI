import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signin } from '../api/auth';

const SignIn = () => {
  const [form, setForm] = useState({ username: '', password: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await signin(form);
      const token = res.data.token;
      localStorage.setItem('token', token);
      setMessage('✅ Signin successful!');
      navigate('/dashboard');
    } catch (err) {
      setMessage(
        '❌ Signin failed: ' +
          (err.response?.data?.message || err.message)
      );
    }
  };

  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <input
        name="username"
        placeholder="Username"
        onChange={handleChange}
        required
      />
      <input
        name="password"
        type="password"
        placeholder="Password"
        onChange={handleChange}
        required
      />
      <button type="submit">Sign In</button>
      {message && <p>{message}</p>}
    </form>
  );
};

const formStyle = {
  display: 'flex',
  flexDirection: 'column',
  gap: '0.5rem',
};

export default SignIn;
