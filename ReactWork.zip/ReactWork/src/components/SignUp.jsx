// src/components/SignUp.jsx

import React, { useState } from 'react';
import { signup } from '../api/auth';

const SignUp = () => {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    roles: [],
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleRoleChange = (e) => {
    const role = e.target.value;
    const isChecked = e.target.checked;

    setForm((prev) => ({
      ...prev,
      roles: isChecked
        ? [...prev.roles, role]
        : prev.roles.filter((r) => r !== role),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await signup(form);
      setMessage('✅ Signup successful!');
    } catch (err) {
      setMessage(
        '❌ Signup failed: ' +
          (err.response?.data?.message || err.message)
      );
    }
  };

  return (
    <form onSubmit={handleSubmit} style={formStyle}>
      <input name="username" placeholder="Username" onChange={handleChange} required />
      <input name="email" placeholder="Email" onChange={handleChange} type="email" required />
      <input name="password" type="password" placeholder="Password" onChange={handleChange} required />

      <div style={{ textAlign: 'left', marginTop: '0.5rem' }}>
        <label>
          <input type="checkbox" value="USER" onChange={handleRoleChange} /> USER
        </label>
        <br />
        <label>
          <input type="checkbox" value="ADMIN" onChange={handleRoleChange} /> ADMIN
        </label>
      </div>

      <button type="submit">Sign Up</button>
      {message && <p>{message}</p>}
    </form>
  );
};

const formStyle = {
  display: 'flex',
  flexDirection: 'column',
  gap: '0.5rem',
};

export default SignUp;
