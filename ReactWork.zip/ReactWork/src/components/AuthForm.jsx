import React, { useState } from 'react';
import SignIn from './SignIn';
import SignUp from './SignUp';

const AuthForm = () => {
  const [isSignUp, setIsSignUp] = useState(false);

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>{isSignUp ? 'Sign Up' : 'Sign In'}</h2>
        {isSignUp ? <SignUp /> : <SignIn />}
        <p style={styles.switchText}>
          {isSignUp ? 'Already have an account?' : "Don't have an account?"}
          <button style={styles.switchBtn} onClick={() => setIsSignUp(!isSignUp)}>
            {isSignUp ? 'Sign In' : 'Sign Up'}
          </button>
        </p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: '#f5f5f5',
  },
  card: {
    background: 'white',
    padding: '2rem',
    borderRadius: '8px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
    width: '300px',
    textAlign: 'center',
  },
  switchText: {
    marginTop: '1rem',
  },
  switchBtn: {
    marginLeft: '0.5rem',
    background: 'none',
    border: 'none',
    color: '#007bff',
    cursor: 'pointer',
    textDecoration: 'underline',
    padding: 0,
    fontSize: '1em',
  },
};

export default AuthForm;
